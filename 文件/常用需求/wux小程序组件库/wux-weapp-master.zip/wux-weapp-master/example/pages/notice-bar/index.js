Page({
    onClick() {
        wx.showModal({
            title: 'Thank you for your support!',
            showCancel: !1,
        })
    },
})